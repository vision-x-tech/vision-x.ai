import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { Mail, Linkedin, Send, MapPin, Phone } from 'lucide-react';

export function ContactUs() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-blue-400 to-cyan-500 bg-clip-text text-transparent mb-4">
              تواصل معنا
            </h2>
            <p className="text-xl text-blue-200/70">نحن هنا للإجابة على استفساراتك</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            <GlassCard>
              <h3 className="text-2xl font-bold text-white mb-6">معلومات الاتصال</h3>

              <div className="space-y-6">
                <motion.a
                  href="mailto:vision.x@outlook.sa"
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center gap-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-blue-400/30 rounded-lg p-4 transition-all group"
                >
                  <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center group-hover:bg-blue-500/30 transition-all">
                    <Mail className="text-blue-400" size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="text-white/60 text-sm mb-1">البريد الإلكتروني</div>
                    <div className="text-white font-mono text-lg">vision.x@outlook.sa</div>
                  </div>
                  <Send className="text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" size={20} />
                </motion.a>

                <motion.a
                  href="https://www.linkedin.com/in/vision-x/"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center gap-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-400/30 rounded-lg p-4 transition-all group"
                >
                  <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center group-hover:bg-cyan-500/30 transition-all">
                    <Linkedin className="text-cyan-400" size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="text-white/60 text-sm mb-1">LinkedIn</div>
                    <div className="text-white text-lg">linkedin.com/in/vision-x</div>
                  </div>
                  <Send className="text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity" size={20} />
                </motion.a>

                <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-lg p-4">
                  <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                    <MapPin className="text-purple-400" size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="text-white/60 text-sm mb-1">المقر الرئيسي</div>
                    <div className="text-white">المملكة العربية السعودية</div>
                  </div>
                </div>

                <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-lg p-4">
                  <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                    <Phone className="text-green-400" size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="text-white/60 text-sm mb-1">ساعات العمل</div>
                    <div className="text-white">الأحد - الخميس: 9:00 - 18:00</div>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-lg">
                <p className="text-blue-200 text-sm text-center">
                  💡 نستجيب عادةً خلال 24 ساعة عمل
                </p>
              </div>
            </GlassCard>

            <GlassCard>
              <h3 className="text-2xl font-bold text-white mb-6">أرسل لنا رسالة</h3>

              <form className="space-y-4">
                <div>
                  <label className="block text-white/70 text-sm mb-2">الاسم الكامل</label>
                  <input
                    type="text"
                    placeholder="أدخل اسمك"
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-blue-400/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">البريد الإلكتروني</label>
                  <input
                    type="email"
                    placeholder="example@company.com"
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-blue-400/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">الشركة / المؤسسة</label>
                  <input
                    type="text"
                    placeholder="اسم الشركة (اختياري)"
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-blue-400/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">الموضوع</label>
                  <select className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-400/50 transition-all">
                    <option value="" className="bg-gray-900">اختر الموضوع</option>
                    <option value="investment" className="bg-gray-900">فرص استثمارية</option>
                    <option value="partnership" className="bg-gray-900">شراكات استراتيجية</option>
                    <option value="licensing" className="bg-gray-900">ترخيص التقنيات</option>
                    <option value="consulting" className="bg-gray-900">استشارات تقنية</option>
                    <option value="media" className="bg-gray-900">استفسارات إعلامية</option>
                    <option value="other" className="bg-gray-900">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">الرسالة</label>
                  <textarea
                    rows={5}
                    placeholder="أخبرنا كيف يمكننا مساعدتك..."
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-blue-400/50 transition-all resize-none"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white py-4 rounded-lg font-bold transition-all transform hover:scale-105 flex items-center justify-center gap-2"
                >
                  <Send size={20} />
                  إرسال الرسالة
                </button>
              </form>

              <div className="mt-6 text-center text-white/50 text-xs">
                بإرسال هذا النموذج، أنت توافق على سياسة الخصوصية الخاصة بنا
              </div>
            </GlassCard>
          </div>

          <div className="mt-12">
            <GlassCard className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10">
              <div className="text-center py-6">
                <h3 className="text-2xl font-bold text-white mb-4">هل تفضل اجتماعاً مباشراً؟</h3>
                <p className="text-white/70 mb-6">
                  احجز مكالمة مع فريقنا التنفيذي لمناقشة فرصك الاستثمارية أو احتياجاتك التقنية
                </p>
                <button className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white px-8 py-3 rounded-lg font-bold transition-all transform hover:scale-105">
                  احجز موعداً الآن
                </button>
              </div>
            </GlassCard>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
