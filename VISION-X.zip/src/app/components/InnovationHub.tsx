import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { Newspaper, Rocket, Beaker, TrendingUp } from 'lucide-react';

export function InnovationHub() {
  const newsItems = [
    {
      category: 'اختراق علمي',
      title: 'نجاح أول اتصال FWFI عبر 100 كيلومتر',
      date: '2 مايو 2026',
      icon: Rocket,
      color: 'blue',
    },
    {
      category: 'شراكة استراتيجية',
      title: 'VISION-X توقع عقداً مع وزارة الدفاع السعودية',
      date: '28 أبريل 2026',
      icon: TrendingUp,
      color: 'green',
    },
    {
      category: 'بحث وتطوير',
      title: 'نشر ورقة علمية في Nature Physics عن التشابك الكمي',
      date: '15 أبريل 2026',
      icon: Beaker,
      color: 'purple',
    },
  ];

  const innovations = [
    {
      title: 'FWFI Protocol v3.0',
      description: 'بروتوكول اتصالات محسّن يضاعف سرعة النقل',
      progress: 85,
      status: 'قيد التطوير',
      team: '12 مهندس',
    },
    {
      title: 'Quantum Mesh Network',
      description: 'شبكة كمية موزعة للاتصالات الآمنة',
      progress: 60,
      status: 'اختبارات ميدانية',
      team: '8 علماء',
    },
    {
      title: 'Neural Interface Alpha',
      description: 'واجهة عصبية للتحكم في أنظمة FWFI بالفكر',
      progress: 35,
      status: 'مرحلة البحث',
      team: '15 باحث',
    },
  ];

  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent mb-4">
              مركز الابتكار والأخبار
            </h2>
            <p className="text-xl text-amber-200/70">آخر التطورات ومستودع الاختراعات</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            {newsItems.map((news, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassCard className="hover:border-white/30 transition-all cursor-pointer h-full">
                  <div className="flex items-start gap-3 mb-4">
                    <div className={`w-12 h-12 rounded-full bg-${news.color}-500/20 flex items-center justify-center flex-shrink-0`}>
                      <news.icon className={`text-${news.color}-400`} size={24} />
                    </div>
                    <div className="flex-1">
                      <div className={`text-${news.color}-300 text-xs mb-1`}>{news.category}</div>
                      <div className="text-white/60 text-xs">{news.date}</div>
                    </div>
                  </div>
                  <h3 className="text-white font-bold text-lg mb-3 leading-tight">{news.title}</h3>
                  <button className="text-blue-400 text-sm hover:text-blue-300 transition-colors">
                    اقرأ المزيد ←
                  </button>
                </GlassCard>
              </motion.div>
            ))}
          </div>

          <GlassCard className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <Newspaper className="text-amber-400" size={32} />
              <h3 className="text-2xl font-bold text-white">النشرة البحثية الشهرية</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <p className="text-white/70 mb-6 leading-relaxed">
                  اشترك في نشرتنا الشهرية للحصول على تقارير حصرية عن أحدث الاختراقات العلمية، التحليلات السوقية، والفرص الاستثمارية قبل الإعلان العام
                </p>
                <div className="flex gap-3">
                  <input
                    type="email"
                    placeholder="بريدك الإلكتروني"
                    className="flex-1 bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-amber-400/50"
                  />
                  <button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-6 py-3 rounded-lg transition-all transform hover:scale-105 whitespace-nowrap">
                    اشترك مجاناً
                  </button>
                </div>
              </div>
              <div className="bg-black/30 rounded-lg p-4 border border-amber-500/20">
                <div className="text-amber-300 text-sm mb-3">ما ستحصل عليه:</div>
                <ul className="space-y-2 text-white/70 text-sm">
                  <li>✓ تقارير بحثية حصرية (قيمة $500/شهر)</li>
                  <li>✓ دعوات لفعاليات VIP والندوات</li>
                  <li>✓ وصول مبكر للمنتجات الجديدة</li>
                  <li>✓ تحليلات سوقية أسبوعية</li>
                </ul>
              </div>
            </div>
          </GlassCard>

          <div>
            <h3 className="text-3xl font-bold text-white mb-6 text-center">مستودع الابتكارات النشطة</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              {innovations.map((innovation, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.15 }}
                >
                  <GlassCard className="h-full">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="text-white font-bold text-lg">{innovation.title}</h4>
                      <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full whitespace-nowrap">
                        {innovation.status}
                      </span>
                    </div>
                    <p className="text-white/60 text-sm mb-4">{innovation.description}</p>

                    <div className="mb-4">
                      <div className="flex justify-between text-xs mb-2">
                        <span className="text-white/60">نسبة الإنجاز</span>
                        <span className="text-white font-mono">{innovation.progress}%</span>
                      </div>
                      <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${innovation.progress}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, delay: index * 0.2 }}
                          className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-white/60 text-sm">
                      <div className="w-2 h-2 rounded-full bg-green-400" />
                      <span>{innovation.team} يعملون عليه</span>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mt-8 text-center">
            <button className="bg-white/10 hover:bg-white/20 border border-white/20 text-white px-8 py-3 rounded-lg transition-all transform hover:scale-105">
              عرض جميع المشاريع البحثية (47 مشروع نشط)
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
