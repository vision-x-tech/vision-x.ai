import { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
}

export function GlassCard({ children, className = '' }: GlassCardProps) {
  return (
    <div
      className={`bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl ${className}`}
      style={{
        boxShadow: '0 8px 32px 0 rgba(0, 150, 255, 0.2)',
      }}
    >
      {children}
    </div>
  );
}
