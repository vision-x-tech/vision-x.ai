import { motion } from 'motion/react';
import { Zap, Waves, Atom, Brain } from 'lucide-react';

export function Hero() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center px-6 relative">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-center max-w-5xl"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: 'spring' }}
          className="inline-block mb-8"
        >
          <div className="relative">
            <div className="absolute inset-0 blur-3xl bg-blue-500/30 rounded-full" />
            <h1 className="text-8xl font-bold relative bg-gradient-to-r from-blue-400 via-cyan-300 to-blue-500 bg-clip-text text-transparent">
              VISION-X
            </h1>
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-2xl text-blue-200/80 mb-4"
        >
          قيادة ثورة هندسة الوسط والاتصالات الكمية
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-lg text-white/60 mb-12 max-w-3xl mx-auto"
        >
          نحن تكتل تكنولوجي يعيد تعريف المستقبل من خلال أربعة أذرع استراتيجية تجمع بين الفيزياء الكمية والهندسة المتقدمة
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="flex flex-wrap gap-6 justify-center"
        >
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-md border border-blue-500/30 rounded-full px-6 py-3">
            <Zap className="text-blue-400" size={24} />
            <span className="text-white">Quantum & Tech</span>
          </div>
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-md border border-cyan-500/30 rounded-full px-6 py-3">
            <Waves className="text-cyan-400" size={24} />
            <span className="text-white">Deep-Wave</span>
          </div>
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-md border border-purple-500/30 rounded-full px-6 py-3">
            <Atom className="text-purple-400" size={24} />
            <span className="text-white">Aether-Genesis</span>
          </div>
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-md border border-pink-500/30 rounded-full px-6 py-3">
            <Brain className="text-pink-400" size={24} />
            <span className="text-white">Sovereign Telepathy</span>
          </div>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-10"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <div className="w-6 h-10 border-2 border-blue-400/50 rounded-full flex items-start justify-center p-2">
            <div className="w-1.5 h-3 bg-blue-400 rounded-full" />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
