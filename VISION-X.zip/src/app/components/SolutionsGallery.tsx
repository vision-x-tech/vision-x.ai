import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { Award, Target, CheckCircle2, ArrowRight } from 'lucide-react';

export function SolutionsGallery() {
  const caseStudies = [
    {
      client: 'شركة أرامكو السعودية',
      industry: 'النفط والغاز',
      challenge: 'صعوبة الاتصال بمنصات النفط البحرية على عمق 2000 متر',
      solution: 'نشر نظام Deep-Wave للاتصالات تحت الماء',
      results: [
        'تحسين الاتصال بنسبة 340%',
        'تقليل وقت الاستجابة للطوارئ من 4 ساعات إلى 15 دقيقة',
        'توفير $2.3M سنوياً في تكاليف الصيانة',
      ],
      roi: '580%',
      duration: '8 أشهر',
      color: 'cyan',
    },
    {
      client: 'الدفاع المدني الإماراتي',
      industry: 'الإنقاذ والطوارئ',
      challenge: 'تحديد موقع الناجين في حوادث انهيار المباني',
      solution: 'تجهيز 50 فريق إنقاذ بتقنية Wall-Sight',
      results: [
        'إنقاذ 127 شخص في أول 6 أشهر',
        'تقليل زمن البحث بنسبة 75%',
        'زيادة معدل البقاء على قيد الحياة إلى 92%',
      ],
      roi: 'لا يُقدر بثمن',
      duration: '3 أشهر',
      color: 'orange',
    },
    {
      client: 'شركة NEOM',
      industry: 'المدن الذكية',
      challenge: 'توفير إنترنت عالي السرعة في مناطق نائية دون بنية تحتية',
      solution: 'إطلاق شبكة Horizon FWFI على مساحة 150 كم²',
      results: [
        'تغطية 100% للمنطقة المستهدفة',
        'سرعات تصل إلى 8 Gbps',
        'توفير $15M في تكاليف مد الكابلات',
      ],
      roi: '420%',
      duration: '5 أشهر',
      color: 'blue',
    },
  ];

  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-emerald-400 to-teal-500 bg-clip-text text-transparent mb-4">
              معرض الحلول
            </h2>
            <p className="text-xl text-emerald-200/70">قصص نجاح حقيقية من عملائنا</p>
          </div>

          <div className="space-y-8">
            {caseStudies.map((study, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
              >
                <GlassCard className="hover:border-white/30 transition-all">
                  <div className="grid lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-1 border-b lg:border-b-0 lg:border-l border-white/10 pb-6 lg:pb-0 lg:pl-6">
                      <div className={`inline-block bg-${study.color}-500/20 text-${study.color}-300 px-3 py-1 rounded-full text-sm mb-4`}>
                        {study.industry}
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2">{study.client}</h3>

                      <div className="space-y-3 mt-6">
                        <div className="flex items-center gap-2">
                          <Target className="text-red-400" size={18} />
                          <div>
                            <div className="text-white/60 text-xs">ROI المحقق</div>
                            <div className="text-white font-bold">{study.roi}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Award className="text-yellow-400" size={18} />
                          <div>
                            <div className="text-white/60 text-xs">مدة المشروع</div>
                            <div className="text-white font-bold">{study.duration}</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="lg:col-span-2 space-y-4">
                      <div>
                        <div className="text-red-400 text-sm font-bold mb-2">❌ التحدي:</div>
                        <p className="text-white/70">{study.challenge}</p>
                      </div>

                      <div>
                        <div className="text-blue-400 text-sm font-bold mb-2">💡 الحل:</div>
                        <p className="text-white/70">{study.solution}</p>
                      </div>

                      <div>
                        <div className="text-green-400 text-sm font-bold mb-3">✅ النتائج المحققة:</div>
                        <div className="grid md:grid-cols-3 gap-3">
                          {study.results.map((result, idx) => (
                            <div
                              key={idx}
                              className="bg-green-500/10 border border-green-500/20 rounded-lg p-3"
                            >
                              <CheckCircle2 className="text-green-400 mb-2" size={20} />
                              <p className="text-white/80 text-sm">{result}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-4">
                        <button className={`text-${study.color}-400 hover:text-${study.color}-300 transition-colors flex items-center gap-2 text-sm font-bold`}>
                          اقرأ دراسة الحالة الكاملة
                          <ArrowRight size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <GlassCard className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10">
              <div className="py-8">
                <h3 className="text-3xl font-bold text-white mb-4">هل تريد أن تكون قصة النجاح القادمة؟</h3>
                <p className="text-white/70 mb-6 max-w-2xl mx-auto">
                  انضم إلى 50+ شركة ومؤسسة حكومية حول العالم تثق في تقنياتنا لحل أصعب التحديات
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white px-8 py-3 rounded-lg transition-all transform hover:scale-105">
                    ابدأ مشروعك
                  </button>
                  <button className="bg-white/10 hover:bg-white/20 border border-white/20 text-white px-8 py-3 rounded-lg transition-all">
                    تصفح جميع الحالات (50+)
                  </button>
                </div>
              </div>
            </GlassCard>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
