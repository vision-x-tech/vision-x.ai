import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { Cpu, Radio, Orbit } from 'lucide-react';

export function QuantumTech() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent mb-4">
              التقنيات المتقدمة
            </h2>
            <p className="text-xl text-blue-200/70">Quantum & Tech | Deep-Wave | Aether-Genesis | Sovereign Telepathy</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <GlassCard>
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mb-4">
                  <Radio className="text-blue-400" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Quantum & Tech</h3>
                <p className="text-white/70 leading-relaxed mb-4">
                  تقنية FWFI - نظام تشغيل للفضاء الحر عبر التداخل الموجي
                </p>
                <div className="bg-blue-500/10 rounded-lg p-3 w-full">
                  <div className="text-blue-300 text-sm">سرعة النقل: 10 Gbps</div>
                  <div className="text-blue-300 text-sm">المدى: 50 km</div>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-cyan-500/20 flex items-center justify-center mb-4">
                  <Orbit className="text-cyan-400" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Deep-Wave</h3>
                <p className="text-white/70 leading-relaxed mb-4">
                  الإنترنت في أعماق المحيطات حتى 5000 متر
                </p>
                <div className="bg-cyan-500/10 rounded-lg p-3 w-full">
                  <div className="text-cyan-300 text-sm">السرعة: 2.4 Gbps</div>
                  <div className="text-cyan-300 text-sm">العمق: حتى 5000m</div>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center mb-4">
                  <Cpu className="text-purple-400" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Aether-Genesis</h3>
                <p className="text-white/70 leading-relaxed mb-4">
                  تجسيد المادة من الطاقة - Matter-as-a-Service
                </p>
                <div className="bg-purple-500/10 rounded-lg p-3 w-full">
                  <div className="text-purple-300 text-sm">MaaS: $15K-$45K/شهر</div>
                </div>
              </div>
            </GlassCard>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
