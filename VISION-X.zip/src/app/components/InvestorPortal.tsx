import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { TrendingUp, DollarSign } from 'lucide-react';

export function InvestorPortal() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-4">
              بوابة المستثمرين
            </h2>
            <p className="text-xl text-green-200/70">فرصة استثمارية تاريخية في تكنولوجيا المستقبل</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            <GlassCard>
              <div className="flex items-center gap-3 mb-6">
                <TrendingUp className="text-green-400" size={32} />
                <h3 className="text-2xl font-bold text-white">نظرة عامة على التقييم</h3>
              </div>

              <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-lg p-6 mb-6">
                <div className="text-center">
                  <div className="text-green-300 text-sm mb-2">التقييم الحالي لـ VISION-X</div>
                  <div className="text-6xl font-bold text-white mb-4">$400M</div>
                  <div className="text-green-200 text-sm">تقييم مبدئي - جولة Series A</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="text-white/60 text-sm mb-1">النمو السنوي المتوقع</div>
                  <div className="text-2xl font-bold text-green-400">240%</div>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="text-white/60 text-sm mb-1">ROI المتوقع (5 سنوات)</div>
                  <div className="text-2xl font-bold text-green-400">12x</div>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex items-center gap-3 mb-6">
                <DollarSign className="text-yellow-400" size={32} />
                <h3 className="text-2xl font-bold text-white">توقعات الإيرادات</h3>
              </div>

              <div className="space-y-4">
                <div className="bg-white/5 rounded-lg p-4 border border-yellow-500/20">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white font-bold">2026</span>
                    <span className="text-yellow-400 text-sm">السنة الحالية</span>
                  </div>
                  <div className="text-3xl font-bold text-white">$12M</div>
                </div>

                <div className="bg-white/5 rounded-lg p-4 border border-green-500/20">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white font-bold">2027</span>
                    <span className="text-green-400 text-sm">متوقع</span>
                  </div>
                  <div className="text-3xl font-bold text-white">$45M</div>
                </div>

                <div className="bg-white/5 rounded-lg p-4 border border-blue-500/20">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white font-bold">2028</span>
                    <span className="text-blue-400 text-sm">متوقع</span>
                  </div>
                  <div className="text-3xl font-bold text-white">$120M</div>
                </div>
              </div>
            </GlassCard>
          </div>

          <GlassCard>
            <div className="text-center">
              <h3 className="text-3xl font-bold text-white mb-6">هل أنت مستعد للانضمام إلى المستقبل؟</h3>
              <p className="text-white/70 mb-8 max-w-3xl mx-auto">
                نبحث عن مستثمرين استراتيجيين يشاركوننا الرؤية في بناء البنية التحتية التكنولوجية للقرن الحادي والعشرين.
              </p>
              <button className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-8 py-4 rounded-lg text-lg font-bold transition-all transform hover:scale-105 shadow-2xl">
                طلب حزمة المستثمرين الكاملة
              </button>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </section>
  );
}
