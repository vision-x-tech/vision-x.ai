import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { Bot, Sparkles, ChartLine, Lightbulb } from 'lucide-react';

export function AIConsulting() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-violet-400 to-fuchsia-500 bg-clip-text text-transparent mb-4">
              استشارات تقنية ذكية
            </h2>
            <p className="text-xl text-violet-200/70">مدعومة برؤية أولية بالذكاء الاصطناعي</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            <GlassCard className="bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10">
              <div className="flex items-center gap-3 mb-6">
                <Bot className="text-violet-400" size={32} />
                <h3 className="text-2xl font-bold text-white">التحليل الذكي المسبق</h3>
              </div>
              <p className="text-white/70 mb-6 leading-relaxed">
                قبل حتى أن تبدأ الاستشارة، يقوم نظامنا الذكي بتحليل بياناتك ومجال عملك لإنشاء رؤية أولية شاملة تختصر أسابيع من البحث إلى دقائق
              </p>

              <div className="space-y-4">
                <div className="bg-violet-500/10 rounded-lg p-4 border border-violet-500/20">
                  <div className="flex items-start gap-3">
                    <Sparkles className="text-violet-400 mt-1 flex-shrink-0" size={20} />
                    <div>
                      <div className="text-white font-bold mb-1">تحليل تنافسي فوري</div>
                      <p className="text-white/60 text-sm">مسح شامل لمنافسيك وتحديد الفجوات في السوق خلال 24 ساعة</p>
                    </div>
                  </div>
                </div>

                <div className="bg-violet-500/10 rounded-lg p-4 border border-violet-500/20">
                  <div className="flex items-start gap-3">
                    <ChartLine className="text-fuchsia-400 mt-1 flex-shrink-0" size={20} />
                    <div>
                      <div className="text-white font-bold mb-1">توقعات النمو الذكية</div>
                      <p className="text-white/60 text-sm">نماذج تنبؤية مدعومة بالذكاء الاصطناعي لتوقع مسار نموك المالي</p>
                    </div>
                  </div>
                </div>

                <div className="bg-violet-500/10 rounded-lg p-4 border border-violet-500/20">
                  <div className="flex items-start gap-3">
                    <Lightbulb className="text-yellow-400 mt-1 flex-shrink-0" size={20} />
                    <div>
                      <div className="text-white font-bold mb-1">اقتراحات تقنية مخصصة</div>
                      <p className="text-white/60 text-sm">توصيات دقيقة للتقنيات المناسبة لحالتك الفريدة</p>
                    </div>
                  </div>
                </div>
              </div>
            </GlassCard>

            <div className="space-y-6">
              <GlassCard>
                <h3 className="text-xl font-bold text-white mb-4">كيف تعمل الاستشارة؟</h3>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-violet-500/20 flex items-center justify-center text-violet-300 font-bold flex-shrink-0">
                      1
                    </div>
                    <div>
                      <div className="text-white font-bold mb-1">إدخال البيانات</div>
                      <p className="text-white/60 text-sm">ارفع وثائقك أو أجب عن استبيان ذكي (15 دقيقة)</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-violet-500/20 flex items-center justify-center text-violet-300 font-bold flex-shrink-0">
                      2
                    </div>
                    <div>
                      <div className="text-white font-bold mb-1">التحليل الآلي</div>
                      <p className="text-white/60 text-sm">الذكاء الاصطناعي يحلل بياناتك ويقارنها بـ 50,000+ حالة سابقة</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-violet-500/20 flex items-center justify-center text-violet-300 font-bold flex-shrink-0">
                      3
                    </div>
                    <div>
                      <div className="text-white font-bold mb-1">التقرير الأولي</div>
                      <p className="text-white/60 text-sm">احصل على رؤية شاملة بـ 40+ صفحة خلال 48 ساعة</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-fuchsia-500/20 flex items-center justify-center text-fuchsia-300 font-bold flex-shrink-0">
                      4
                    </div>
                    <div>
                      <div className="text-white font-bold mb-1">جلسة مع الخبراء</div>
                      <p className="text-white/60 text-sm">اجتماع مع مستشارينا لمناقشة التقرير وبناء خطة عمل</p>
                    </div>
                  </div>
                </div>
              </GlassCard>

              <GlassCard className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/30">
                <div className="text-center">
                  <div className="text-green-300 text-sm mb-2">عرض خاص - الاستشارة الأولى</div>
                  <div className="text-5xl font-bold text-white mb-2">مجاناً</div>
                  <p className="text-white/70 text-sm mb-4">التقرير الأولي + 30 دقيقة استشارة</p>
                  <button className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 text-white py-3 rounded-lg transition-all transform hover:scale-105">
                    احصل على رؤيتك المجانية
                  </button>
                </div>
              </GlassCard>
            </div>
          </div>

          <GlassCard>
            <h3 className="text-2xl font-bold text-white mb-6 text-center">مجالات الاستشارة</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-white/5 border border-violet-500/20 rounded-lg p-4 text-center hover:border-violet-400/50 transition-all cursor-pointer">
                <div className="text-3xl mb-2">🚀</div>
                <div className="text-white font-bold mb-1">التحول الرقمي</div>
                <p className="text-white/60 text-xs">نقل عملياتك إلى المستقبل</p>
              </div>
              <div className="bg-white/5 border border-fuchsia-500/20 rounded-lg p-4 text-center hover:border-fuchsia-400/50 transition-all cursor-pointer">
                <div className="text-3xl mb-2">🧠</div>
                <div className="text-white font-bold mb-1">استراتيجية الذكاء الاصطناعي</div>
                <p className="text-white/60 text-xs">دمج AI في نموذج عملك</p>
              </div>
              <div className="bg-white/5 border border-blue-500/20 rounded-lg p-4 text-center hover:border-blue-400/50 transition-all cursor-pointer">
                <div className="text-3xl mb-2">☁️</div>
                <div className="text-white font-bold mb-1">البنية السحابية</div>
                <p className="text-white/60 text-xs">تصميم وترحيل الأنظمة</p>
              </div>
              <div className="bg-white/5 border border-purple-500/20 rounded-lg p-4 text-center hover:border-purple-400/50 transition-all cursor-pointer">
                <div className="text-3xl mb-2">🔐</div>
                <div className="text-white font-bold mb-1">الأمن السيبراني</div>
                <p className="text-white/60 text-xs">حماية شاملة وتقييم</p>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </section>
  );
}
