import { motion } from 'motion/react';
import { GlassCard } from './GlassCard';
import { Check, Star, Zap, Crown } from 'lucide-react';

export function PricingPlans() {
  const plans = [
    {
      name: 'Startup',
      icon: Zap,
      price: '$2,500',
      period: 'شهرياً',
      description: 'مثالي للشركات الناشئة والفرق الصغيرة',
      color: 'blue',
      popular: false,
      features: [
        'استشارة AI أولية مجانية',
        'وصول لمكتبة التقنيات الأساسية',
        'دعم فني عبر البريد (48 ساعة)',
        '3 جلسات استشارية شهرياً',
        'تقارير شهرية عن الأداء',
        'وصول لمركز الأخبار والابتكار',
      ],
    },
    {
      name: 'Professional',
      icon: Star,
      price: '$8,500',
      period: 'شهرياً',
      description: 'للشركات المتوسطة التي تريد نمواً سريعاً',
      color: 'purple',
      popular: true,
      features: [
        'كل ميزات Startup',
        'استشارات غير محدودة',
        'دعم فني مباشر (6 ساعات)',
        'وصول حصري لـ 10 تقنيات متقدمة',
        'جلسات تدريب شهرية للفريق',
        'تقارير أسبوعية مخصصة',
        'خصم 15% على تراخيص المنتجات',
        'مدير حساب مخصص',
      ],
    },
    {
      name: 'Enterprise',
      icon: Crown,
      price: 'مخصص',
      period: 'حسب الاحتياج',
      description: 'حلول كاملة للمؤسسات الكبرى',
      color: 'amber',
      popular: false,
      features: [
        'كل ميزات Professional',
        'بنية تحتية مخصصة بالكامل',
        'دعم فني على مدار الساعة',
        'وصول غير محدود لجميع التقنيات',
        'تطوير حلول مخصصة حسب الطلب',
        'فريق تقني مخصص لك',
        'SLA مضمون 99.9%',
        'تدريب داخلي في موقعك',
        'استشارة استراتيجية ربع سنوية مع CEO',
      ],
    },
  ];

  return (
    <section className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-7xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-6xl font-bold bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent mb-4">
              خطط الأسعار
            </h2>
            <p className="text-xl text-indigo-200/70">مرونة تناسب جميع أحجام الأعمال</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {plans.map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={plan.popular ? 'lg:-mt-4 lg:mb-4' : ''}
              >
                <GlassCard
                  className={`h-full ${
                    plan.popular
                      ? `bg-gradient-to-br from-${plan.color}-500/20 to-${plan.color}-600/20 border-${plan.color}-400/50 relative`
                      : ''
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-2 rounded-full text-sm font-bold shadow-xl">
                      الأكثر شعبية ⭐
                    </div>
                  )}

                  <div className={`w-16 h-16 rounded-full bg-${plan.color}-500/20 flex items-center justify-center mb-4 ${plan.popular ? 'mt-4' : ''}`}>
                    <plan.icon className={`text-${plan.color}-400`} size={32} />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                  <p className="text-white/60 text-sm mb-6">{plan.description}</p>

                  <div className="mb-6">
                    <div className="flex items-end gap-2 mb-1">
                      <span className="text-5xl font-bold text-white">{plan.price}</span>
                      {plan.period !== 'حسب الاحتياج' && (
                        <span className="text-white/60 mb-2">/ {plan.period}</span>
                      )}
                    </div>
                    {plan.period === 'حسب الاحتياج' && (
                      <p className="text-white/60 text-sm">سيتم تحديد السعر بناءً على احتياجاتك</p>
                    )}
                  </div>

                  <button
                    className={`w-full py-3 rounded-lg font-bold transition-all transform hover:scale-105 mb-6 ${
                      plan.popular
                        ? `bg-gradient-to-r from-${plan.color}-500 to-pink-500 hover:from-${plan.color}-600 hover:to-pink-600 text-white`
                        : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
                    }`}
                  >
                    {plan.price === 'مخصص' ? 'تواصل معنا' : 'ابدأ الآن'}
                  </button>

                  <div className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <Check className={`text-${plan.color}-400 flex-shrink-0 mt-0.5`} size={18} />
                        <span className="text-white/80 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>

          <GlassCard>
            <div className="text-center py-6">
              <h3 className="text-2xl font-bold text-white mb-4">خيارات دفع مرنة</h3>
              <div className="grid md:grid-cols-4 gap-4 max-w-4xl mx-auto">
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="text-3xl mb-2">💳</div>
                  <div className="text-white font-bold mb-1">دفع شهري</div>
                  <p className="text-white/60 text-xs">بدون التزام طويل الأمد</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="text-3xl mb-2">📅</div>
                  <div className="text-white font-bold mb-1">دفع سنوي</div>
                  <p className="text-white/60 text-xs">وفر 20% على الاشتراك</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="text-3xl mb-2">🔄</div>
                  <div className="text-white font-bold mb-1">Pay-as-you-go</div>
                  <p className="text-white/60 text-xs">ادفع فقط عند الاستخدام</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="text-3xl mb-2">🤝</div>
                  <div className="text-white font-bold mb-1">اتفاقيات خاصة</div>
                  <p className="text-white/60 text-xs">للمشاريع الضخمة</p>
                </div>
              </div>
            </div>
          </GlassCard>

          <div className="mt-8 text-center">
            <p className="text-white/60 text-sm mb-4">
              جميع الخطط تشمل: ضمان استرجاع كامل لمدة 30 يوم • تشفير من الدرجة العسكرية • امتثال كامل لـ GDPR و ISO 27001
            </p>
            <button className="text-blue-400 hover:text-blue-300 transition-colors text-sm font-bold">
              مقارنة تفصيلية لجميع الميزات →
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
