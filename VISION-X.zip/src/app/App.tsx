import { WaveFieldBackground } from './components/WaveFieldBackground';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { QuantumTech } from './components/QuantumTech';
import { AIConsulting } from './components/AIConsulting';
import { InnovationHub } from './components/InnovationHub';
import { SolutionsGallery } from './components/SolutionsGallery';
import { PricingPlans } from './components/PricingPlans';
import { InvestorPortal } from './components/InvestorPortal';
import { ContactUs } from './components/ContactUs';

export default function App() {
  return (
    <div className="relative min-h-screen bg-black text-white overflow-x-hidden">
      <WaveFieldBackground />
      <Navigation />

      <div className="relative z-10">
        <div id="hero">
          <Hero />
        </div>

        <div id="quantum">
          <QuantumTech />
        </div>

        <div id="consulting">
          <AIConsulting />
        </div>

        <div id="innovation">
          <InnovationHub />
        </div>

        <div id="solutions">
          <SolutionsGallery />
        </div>

        <div id="pricing">
          <PricingPlans />
        </div>

        <div id="investor">
          <InvestorPortal />
        </div>

        <div id="contact">
          <ContactUs />
        </div>

        <footer className="py-12 px-6 border-t border-white/10">
          <div className="max-w-7xl mx-auto text-center">
            <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent mb-4">
              VISION-X
            </div>
            <p className="text-white/60 mb-6">
              نبني المستقبل، اليوم
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-white/50 mb-6">
              <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-white transition-colors">الشروط والأحكام</a>
              <a href="#" className="hover:text-white transition-colors">اتصل بنا</a>
              <a href="#" className="hover:text-white transition-colors">للإعلام</a>
            </div>
            <p className="text-white/40 text-xs">
              © 2026 VISION-X. جميع الحقوق محفوظة. | تقييم الشركة: $400M
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
