
  # VISION-X

  This is a code bundle for VISION-X. The original project is available at https://www.figma.com/design/Ud8Xtjd9MJfAkVmtVcZ92k/VISION-X.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  